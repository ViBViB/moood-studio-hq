PREOPTIMA — LOGO PACK
Interim release, 2 September 2026. Prepared for the 23 September event.

------------------------------------------------------------------
WHAT IS SETTLED

The mark, the colour and the typography are all approved. Nothing in
this pack is provisional. The full brand book follows, and it will add
master files (.AI, print-ready PDF) and usage rules — but it will not
change the artwork here.

  Ink    #18120F      text and the mark on light grounds
  Rust   #9B3300      the accent — one use per screen or page
  Bone   #F5F1EA      light ground, and the mark reversed on dark
  Clay   #C9BFB1      supporting tone

------------------------------------------------------------------
THE ONE RULE THAT MATTERS

The wordmark is the logo. Use it wherever the name fits.

The symbol is a secondary asset for the places the full name cannot
go — favicon, avatar, app icon, a stamp on a garment. It is not a
second logo and it should not lead a layout.

------------------------------------------------------------------
FILES

svg/     Vector masters. Use these wherever the destination accepts
         SVG — they stay sharp at any size.

  preoptima-wordmark-ink.svg     on light grounds
  preoptima-wordmark-rust.svg    when the mark itself carries the accent
  preoptima-wordmark-bone.svg    reversed, for dark grounds
  preoptima-symbol-*.svg         same three, as the disc

png/     Transparent rasters for anything that will not take SVG.
         Wordmarks at 600 / 1200 / 2400 px wide; symbols at 16, 32,
         48, 180, 192, 512 and 1024 px square.

         Two flat-ground versions are included for platforms that
         reject transparency:
           preoptima-wordmark-ink-on-bone-2400w.png
           preoptima-wordmark-bone-on-ink-2400w.png
         Use these rather than placing a transparent PNG on a white
         box over a coloured background.

favicon/ favicon.ico       rust disc, 16/32/48 — the default
         favicon-ink.ico   the same in ink, if the tab reads better

------------------------------------------------------------------
PRACTICAL NOTES

Clear space   Keep clear on all four sides at least the height of the
              lowercase letters. The flat-ground files above already
              carry it.

Minimum size  Wordmark: 90 px wide on screen, 25 mm in print.
              Symbol:   16 px. It was drawn to hold at that size.

Do not        recolour outside the four values above; stretch or
              condense; add effects, outlines or shadows; rebuild the
              wordmark by typing it in a font — the letterforms are
              drawn, not set.

Questions: alberto.contreras@gmail.com
