PREOPTIMA — LOGO PACK
Reissued 25 September 2026, alongside the final brand style guide.
Palette file updated 5 October 2026 with the confirmed extended palette.
Supersedes the 2 September 2026 interim release, which used a colour
direction (Ink / Rust / Bone) since replaced by the palette below.

------------------------------------------------------------------
WHAT IS SETTLED

The mark, the colour and the typography are all approved, matching
the brand style guide delivered with this pack.

  Mirage      #16232A      text and the mark on light grounds
  Blaze Orange #FF5B04     the accent — one use per screen or page
  Wild Sand   #E4EEF0      light ground, and the mark reversed on dark

------------------------------------------------------------------
THE ONE RULE THAT MATTERS

The wordmark is the logo. Use it wherever the name fits.

The symbol is a secondary asset for the places the full name cannot
go — favicon, avatar, app icon, a stamp on a garment. It is not a
second logo and it should not lead a layout.

------------------------------------------------------------------
FILES

svg/     Vector masters. Use these wherever the destination accepts
         SVG — they stay sharp at any size, and open cleanly in
         Illustrator or any vector editor if a native file is needed.

  preoptima-wordmark-mirage.svg     on light grounds
  preoptima-wordmark-orange.svg     when the mark itself carries the accent
  preoptima-wordmark-wildsand.svg   reversed, for dark grounds
  preoptima-symbol-*.svg            same three, as the disc

  svg/_superseded-ink-rust-bone/    the retired 2 September files, kept
                                     for reference only — do not use.

png/     Transparent rasters for anything that will not take SVG.
         Wordmarks at 600 / 1200 / 2400 px wide; symbols at 16, 32,
         48, 180, 192, 512 and 1024 px square.

         Two flat-ground versions are included for platforms that
         reject transparency:
           preoptima-wordmark-mirage-on-wildsand-2400w.png
           preoptima-wordmark-wildsand-on-mirage-2400w.png
         Use these rather than placing a transparent PNG on a white
         box over a coloured background.

favicon/ favicon.ico          orange disc, 16/32/48 — the default
         favicon-mirage.ico   the same in Mirage, if the tab reads better

preoptima-palette.ase   The full colour system as an Adobe Swatch Exchange
                        file — the cross-application standard, reads
                        natively in Illustrator, InDesign and Photoshop
                        (File > Import/Load Swatches). Two groups:
                        Primary (Mirage, Blaze Orange, Deep Sea Green,
                        Wild Sand) and Extended (Soft Blush, Night
                        Bordeaux, Honeydew, Jungle Teal).

------------------------------------------------------------------
PRACTICAL NOTES

Clear space   Keep clear on all four sides at least the x-height of
              the lowercase letters. The flat-ground files above
              already carry it.

Minimum size  Wordmark: 90 px wide on screen, 25 mm in print.
              Symbol:   16 px. It was drawn to hold at that size.

Do not        recolour outside the three values above; stretch or
              condense; add effects, outlines or shadows; rebuild the
              wordmark by typing it in a font — the letterforms are
              drawn, not set.

No native .AI file is included in this pack. The SVG masters above
open directly in Illustrator (File > Open) with the artwork fully
editable and are the source of truth — ask if a specific format is
still needed for a workflow that can't take SVG.

Questions: alberto.contreras@gmail.com
